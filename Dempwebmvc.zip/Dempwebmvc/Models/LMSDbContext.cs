﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;
using System.Data.Entity;

namespace Dempwebmvc.Models
{
	public class LMSDbContext:DbContext
	{
		public LMSDbContext()
		
			:base(@"Server=WIN2019;Database=LMSDb;Trusted_Connection=true;"){ 
			Database.SetInitializer(new CreateDatabaseIfNotExists<LMSDbContext>()); 
		}
		public DbSet<Course> Courses { get; set; }
		protected override void OnModelCreating(DbModelBuilder modelBuilder)
		{
			base.OnModelCreating(modelBuilder);
		
		 }

        public DbSet<Actor> Users { get; set; }
		public DbSet<Enrollment> Enrollment { get; set; }
    }
}