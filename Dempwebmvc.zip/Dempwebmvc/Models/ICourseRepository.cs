﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dempwebmvc.Models
{
    public interface ICourseRepository
    {
        IEnumerable<Course> GetAllCourse();
        Course GetCourseById(int id);
        void AddCourse(Course course);
    }
}
