﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Dempwebmvc.Models
{
	public class UserRepository:IUserRepository
	{
        private readonly LMSDbContext _context;

        public UserRepository() : this(new LMSDbContext())
        {

        }
        public UserRepository(LMSDbContext context)
        {
            _context=context;
        }
        public IEnumerable<Actor> GetAllUser()
        {
            return _context.Users.ToList();
        }

        public Actor GetUserById(int id)
        {
            return _context.Users.Find(id);
        }

        public string Login(string username,string password)
        {
            return _context.Users.Where<Actor>(c => c.Email == username && c.Password == password).Select(x => x.Role).FirstOrDefault();
        }

        public void AddUser(Actor User)
        {
            _context.Users.Add(User);
            _context.SaveChanges();
        }
    }

}