﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Dempwebmvc.Models
{
	public class EnrollmentViewModel:EnrollmentDTO
	{
		public new int EnrollmentId { get; set; }
        public new int UserId { get; set; }

        public new int CourseId { get; set; }
        public new string EnrollementDate { get; set; }

        public List<EnrollSelectItem> course_item { get; set; }
        public List<EnrollSelectItem> user_list { get; set; }
        public List<EnrollSelectItem> course_list { get; set; }

    }
}