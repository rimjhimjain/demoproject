﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Dempwebmvc.Models
{
	public class EnrollmentRepository:IEnrollmentRepository
	{
        private readonly LMSDbContext _context;

        public EnrollmentRepository() : this(new LMSDbContext())
        {

        }
        public EnrollmentRepository(LMSDbContext context)
        {
            _context=context;
        }
        public IEnumerable<Enrollment> GetAllEnrollments()
        {
            return _context.Enrollment.ToList();
        }

        public Enrollment GetEnrollmentById(int id)
        {
            return _context.Enrollment.Find(id);
        }

        public void AddEnrollment(Enrollment enroll)
        {
            _context.Enrollment.Add(enroll);
            _context.SaveChanges();
        }
    }
}