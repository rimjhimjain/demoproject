﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Dempwebmvc.Models
{
	public class Course
	{
		[Key]
		public int CourseId { get; set; }
		[Required(ErrorMessage ="Please enter course name")]
		[StringLength(50,ErrorMessage ="Course name should not exceed 50 charcaters")]

        public string Title { get; set; }
        [Required(ErrorMessage = "Please enter course duration")]
        [StringLength(50, ErrorMessage = "Course duration should not exceed 50 charcaters")]

		public string Description { get; set; }
		//public virtual ICollection<Enrollment> Enrollments


	}
}