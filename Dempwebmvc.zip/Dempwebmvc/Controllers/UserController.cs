﻿using Dempwebmvc.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Dempwebmvc.Controllers
{
    public class UserController : Controller
    {
        // GET: User
        private readonly IUserRepository _repository;

        public UserController() :this(new UserRepository()){

        }

        public UserController(IUserRepository repository)
        {
            _repository=repository;
        }



        public ActionResult Index(int id)
        {
            if(id == 0){
                ViewBag.Title = "User List";
                ViewData["UsersCount"] = _repository.GetAllUser().Count();
                List<UserViewModel> user_List = _repository.GetAllUser().Select(c => new UserViewModel{
                    UserId = c.UserId,
                        Name = c.Name,
                        Email =c.Email,
                        Password= c.Password,
                        Role = c.Role,
                        Type = Actor.Type.Admin.ToString()}).ToList();
                return View(user_List);
                }
            return Content("Sorry, you are not allowed");
            }

        public ActionResult Details(int id)
        {
            var user = _repository.GetUserById(id);
            UserViewModel uvm = new UserViewModel();
            uvm.UserId=user.UserId;
            uvm.Name=user.Name;
            uvm.Email=user.Email;
            uvm.Password=user.Password;
            uvm.Role=user.Role;
            if (user==null)
            {
                TempData["Error"] = "User not found";
                return RedirectToAction("Index");
            }
            return View(uvm);
        }
        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]

        public ActionResult Login(UserViewModel uvm)
        {
            string role = _repository.Login(uvm.Email, uvm.Password);
            if(role == null)
            {
                TempData["Error"] = "User not found";
                return View();
            }
            return RedirectToAction("Index");
        }

        [HttpGet]
        //authorise

        public ActionResult AddUser()
        {
            ViewBag.TypeList = new List<SelectListItem>
            {
                new SelectListItem{Value = Actor.Type.Admin.ToString(),Text = "Admin"},
                 new SelectListItem{Value = Actor.Type.Instructor.ToString(),Text = "Instructor"},
                 new SelectListItem{Value = Actor.Type.Student.ToString(),Text = "Student"}
            };
            return View();
        }

        [HttpPost]

        public ActionResult AddUser(UserViewModel User)
        {
            if (ModelState.IsValid)
            {
                Actor uvm = new Actor();
                uvm.UserId=User.UserId;
                uvm.Name=User.Name;
                uvm.Email=User.Email;
                uvm.Password=User.Password;
                uvm.Role=User.Role;
                _repository.AddUser(uvm);
                TempData["Success"] = "User added successfully";
                return RedirectToAction("Index");
            }
            return View(User);
        }
        
    }
}