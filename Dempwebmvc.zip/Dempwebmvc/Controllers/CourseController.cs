﻿using Dempwebmvc.Models;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Dempwebmvc.Controllers
{
    public class CourseController : Controller
    {
        // GET: Course
        private readonly ICourseRepository _repository;

        public CourseController() : this(new CourseRepository())
        {

        }

        public CourseController(ICourseRepository repository)
        {
            _repository=repository;
        }

        public ActionResult Index(int id)
        {
            if (id == 0)
            {
                ViewBag.Title = "Course List";
                ViewData["CourseCount"] = _repository.GetAllCourse().Count();
                List<CourseViewModel> course_List = _repository.GetAllCourse().Select(c => new CourseViewModel
                {
                    CourseId=c.CourseId,
                    Title=c.Title,
                    Description=c.Description,
                }).ToList();
                return View(course_List);
            }
            return Content("Sorry, you are not allowed");
        }


        public ActionResult Details(int id)
        {
            var course = _repository.GetCourseById(id);
            CourseViewModel cvm = new CourseViewModel();
            cvm.Title=course.Title;
            cvm.Description=course.Description;
            cvm.CourseId=course.CourseId;
            if(course == null)
            {
                TempData["Error"] = "Course not found";
                return RedirectToAction("Index");
            }

            return View(cvm);
        }

        [HttpGet]
        //authorise

        public ActionResult AddCourse()
        {
            return View();
         
        }


        
        [HttpPost]

        public ActionResult AddCourse(Course course)
        {
            if (ModelState.IsValid)
            {
                _repository.AddCourse(course);
                TempData["Success"] = "course added successfully";
                return RedirectToAction("Index");
            }
            return View(course);
        }


    }
}