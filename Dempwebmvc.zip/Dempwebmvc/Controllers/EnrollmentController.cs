﻿using Dempwebmvc.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Web;
using System.Web.Mvc;

namespace Dempwebmvc.Controllers
{
    public class EnrollmentController : Controller
    {
    private readonly IEnrollmentRepository _repository;
    private readonly IUserRepository _urepository;
    private readonly ICourseRepository _crepository;
        // GET: Enrollment

        public EnrollmentController() : this(new EnrollmentRepository(),new UserRepository(),new CourseRepository())
        {

        }

        public EnrollmentController(IEnrollmentRepository repository,IUserRepository urepository,ICourseRepository crepository)
        {
            _repository= repository;
            _urepository= urepository;
            _crepository=crepository;

        }
        public ActionResult Index(int id)
        {
            if(id == 0)
            {
                ViewBag.Title = "Enrollment List";
                ViewData["EnrollsCount"]=_repository.GetAllEnrollments().Count();
                List<EnrollmentViewModel> enroll_list = _repository.GetAllEnrollments().Select(x => new EnrollmentViewModel{
                    EnrollmentId = x.EnrollmentId,
                        CourseId = x.CourseId,
                        UserId = x.UserId,
                        EnrollmentDate = x.EnrollmentDate,
                        Course = x.Course,
                        Users = x.Users
                }).ToList();
            return View(enroll_list);
            }
        return Content("Sorry you are not allowed");
        }

    public ActionResult Details(int id)
        {
            var enroll = _repository.GetEnrollmentById(id);
            EnrollmentViewModel cvm = new EnrollmentViewModel();
            cvm.EnrollmentId=enroll.EnrollmentId;
            cvm.UserId=enroll.UserId;
            cvm.CourseId=enroll.CourseId;
            cvm.EnrollmentDate=enroll.EnrollmentDate;
            cvm.Course=enroll.Course;
            cvm.Users = enroll.Users;
            
            if (enroll == null)
            {
                TempData["Error"] = "Enrollment not found";
                return RedirectToAction("Index");
            }
            return View(cvm);
        }

        [HttpGet]

        public ActionResult AddEnrollment()
        {
            var model = new EnrollmentViewModel
            {
                course_list=_crepository.GetAllCourse().Select(c => new EnrollSelectItem
                {
                    Id=  c.CourseId,
                    Value = c.CourseId.ToString(),
                    Text = c.Title
                }).ToList(),

                user_list = _urepository.GetAllUser().Select(c => new EnrollSelectItem
                {
                    Id=  c.UserId,
                    Value = c.UserId.ToString(),
                    Text = c.Name
                }).ToList()
            };
            return View(model);
        }

        [HttpPost]

        public ActionResult AddEnrollment(Enrollment enroll)
        {
            if (ModelState.IsValid)
            {
                _repository.AddEnrollment(enroll);
                TempData["Success"] = "enrollment added successfully";
                return RedirectToAction("Index");
            }
            return View(enroll);
        }
    }
}